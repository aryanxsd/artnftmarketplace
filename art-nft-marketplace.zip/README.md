# 🎨 Art NFT Marketplace

This is a full-stack decentralized Art NFT Marketplace built with:

- **Next.js** frontend
- **Solidity** smart contracts (ERC-721 + Marketplace)
- **IPFS** for image storage
- **Ethers.js** & **Web3Modal** for wallet interaction

---

## 📁 Structure

- `contracts/` — NFT and Marketplace smart contracts
- `pages/` — Frontend React components
- `scripts/` — Hardhat deployment scripts

---

## 🚀 Deploy

```bash
# Compile contracts
npx hardhat compile

# Deploy to local
npx hardhat run scripts/deploy.js --network hardhat

# Or deploy to Mumbai
npx hardhat run scripts/deploy.js --network mumbai
```

---

## 🧠 Features

- Upload art to IPFS
- Mint and list NFTs
- Buy NFTs with MATIC
- Fully decentralized marketplace

---

## 🛠️ Setup

```bash
npm install
npm run dev
```

---

Made with 💙 by Priyanshu Aryan
